﻿using HRMS.Models;
using HRMS.Services;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.AspNetCore.Mvc.Rendering;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace HRMS.Pages
{
    public partial class AddDepartment
    {
        [Inject]
        public DepartmentService DepartmentService{ get; set; }
        public CompaniesService companiesService { get; set; }
        Department department = new Department();
        List<Department> capObj;
        public List<SelectListItem> companies = new();
    


        protected override async Task OnInitializedAsync()
        {
            capObj = await DepartmentService.GetAllDepartmentsAsync();
            companies = await DepartmentService.GetAllCompaniesAsync();
        }
     
        protected async void CreateDepartment()
        {
            await DepartmentService.AddDepartment(department);
            NavigationManager.NavigateTo("Department", true);
        }
        [Parameter]
        public string Id { get; set; }

        protected async void EditDepartment(int id)
        {
            department = await DepartmentService.GetDepartmentAsync(id);
            StateHasChanged();
        }

        protected async void DeleteDepartment(int id)
        {
            department = await DepartmentService.GetDepartmentAsync(id);
            await DepartmentService.DeleteDepartment(department);
            NavigationManager.NavigateTo("Department", true);
        }
       
        public async Task Edit()
        {
            department = new();
        }
        
        
       


     


    }
}