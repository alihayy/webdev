﻿using HRMS.Models;
using HRMS.Services;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Forms;

namespace HRMS.Pages
{
    public partial class AddRoles
    {
        [Inject]
        public RolesService rolesService { get; set; }
        Role roles = new Role();
        List<Role> roleObj;
        protected override async Task OnInitializedAsync()
        {
            roleObj = await Task.Run(() => rolesService.GetAllRolesAsync());
        }
        protected async void CreateRole()
        {
            await rolesService.AddRole(roles);
            NavigationManager.NavigateTo("Role", true);
        }
        [Parameter]
        public string Id { get; set; }

        protected async void EditRole(int id)
        {
            roles = await rolesService.GetRolesById(id);
            StateHasChanged();
        }

        protected async void DeleteRole(int id)
        {
            roles = await rolesService.GetRolesById(id);
            await rolesService.DeleteRole(roles);
            NavigationManager.NavigateTo("Role", true);
        }
        public async Task Edit()
        {
            roles = new();
        }


    }
}