﻿using HRMS.Models;
using HRMS.Services;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace HRMS.Pages
{
    public partial class AddEmployee
    {
        [Inject]
        public EmployeeService employeeService { get; set; }
        Employee employee = new Employee();

        public CompaniesService companiesService { get; set; }
        public RolesService rolesService { get; set; }
        List<Employee> EmpObj;
        List<Employee> filteredEmpObj;

        public List<SelectListItem> companies = new();
        public List<SelectListItem> roles = new();
        public List<SelectListItem> departments = new();
        string searchString = "";
        protected override async Task OnInitializedAsync()
        {
            EmpObj = await employeeService.GetAllEmployeesAsync();
            companies = await employeeService.GetAllCompaniesAsync();
            roles = await employeeService.GetAllRolesAsync();
            departments = await employeeService.GetAllDepartmentsAsync();
            FilterEmployees();
        }
        void FilterEmployees()
        {
            if (!string.IsNullOrEmpty(searchString))
            {
                filteredEmpObj = EmpObj.Where(emp => emp.EmployeeName.Contains(searchString, StringComparison.OrdinalIgnoreCase)).ToList();
                
            }
            else
            {
                filteredEmpObj = EmpObj;
                
            }
        }

        void HandleSearch(ChangeEventArgs e)
        {
            searchString = e.Value.ToString();
            FilterEmployees();
        }
        public async void GetDepartmentCompanywise(int companyid)
        {
            try
            {
                departments = new();
                employee.CompanyId = companyid;
                departments = await employeeService.GetDepartmentbyid(companyid);
                StateHasChanged();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        protected async void CreateEmployee()
        {
            await employeeService.AddEmployee(employee);
            NavigationManager.NavigateTo("Employee", true);
        }
        [Parameter]
        public string Id { get; set; }

        protected async void EditEmployee(int id)
        {
            employee = await employeeService.GetEmployeeById(id);
            StateHasChanged();
        }

        protected async void DeleteEmployee(int id)
        {
            employee = await employeeService.GetEmployeeById(id);
            await employeeService.DeleteEmployee(employee);
            NavigationManager.NavigateTo("Employee", true);
        }
        public async Task Edit()
        {
            employee = new();
        }


    }
}


