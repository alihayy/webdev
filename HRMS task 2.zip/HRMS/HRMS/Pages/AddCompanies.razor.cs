﻿using HRMS.Models;
using HRMS.Services;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Forms;

namespace HRMS.Pages
{
    public partial class AddCompanies
    {
        [Inject]
        public CompaniesService CompaniesService { get; set; }
        Company Companies = new Company();
        List<Company> comObj;

        protected override async Task OnInitializedAsync()
        {
            comObj = await CompaniesService.GetAllCompaniesAsync();
        }
        protected async void CreateCompany()
        {
            await CompaniesService.AddCompany(Companies);
            NavigationManager.NavigateTo("Company", true);
        }
        [Parameter]
        public string Id { get; set; }

        protected async void EditCompany(int id)
        {
            Companies = await CompaniesService.GetCompanyById(id);
            StateHasChanged();
        }

        protected async void DeleteCompany(int id)
        {
            Companies = await CompaniesService.GetCompanyById(id);
            await CompaniesService.DeleteCompany(Companies);
            NavigationManager.NavigateTo("Company", true);
        }
        public async Task Edit()
        {
            Companies = new();
        }


    }
}
