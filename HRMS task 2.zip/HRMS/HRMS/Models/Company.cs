﻿using System.ComponentModel.DataAnnotations;

namespace HRMS.Models
{
    public class Company
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string CompanyName { get; set; }

        public string Phone { get; set; }

        [EmailAddress]
        public string Email { get; set; }

        public string Address { get; set; }

        public ICollection<Department> Departments { get; set; }
    }
}
