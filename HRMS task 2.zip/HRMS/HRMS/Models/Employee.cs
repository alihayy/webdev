﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HRMS.Models
{
    public class Employee
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string EmployeeName { get; set; }

        public string Gender { get; set; }

        public string City { get; set; }

        //public string Designation { get; set; }

        [ForeignKey("Department")]
        public int DepartmentId { get; set; }
        [Required]
        public int CompanyId { get; set; }
        public Department Department { get; set; }
        [ForeignKey("Role")]
        public int RoleId { get; set; }

        public Role Role { get; set; }

        internal object ToLower()
        {
            throw new NotImplementedException();
        }
    }
}
