﻿using HRMS.Models;
using Microsoft.AspNetCore.Components;
using Microsoft.EntityFrameworkCore;

namespace HRMS.Services
{
    public class RolesService
    {
        [Parameter]
        public string Id { get; set; }
        protected AppDbContext context;
        public RolesService(AppDbContext context)
        {
            this.context = context;
        }
        public async Task<List<Role>> GetAllRolesAsync()
        {
            return await context.roles.ToListAsync();
        }

        public async Task<bool> AddRole(Role roles)
        {
            if (roles.Id == 0)
            {
                await context.roles.AddAsync(roles);
            }
            var editRoles = context.roles.Where(x => x.Id == roles.Id).FirstOrDefault();
            await context.SaveChangesAsync();
            return true;
        }
        public async Task<Role> GetRolesById(int Id)
        {
            Role roles = await context.roles.FirstOrDefaultAsync(x => x.Id.Equals(Id));
            return roles;
        }


        public async Task<Role> DeleteRole(Role roles)
        {
            if (roles.Id != 0)
            {
                var existingrole = await context.roles.FindAsync(roles.Id);

                context.roles.Remove(existingrole);
                await context.SaveChangesAsync();
                return existingrole;
            }
            return null;
        }

    }
}
