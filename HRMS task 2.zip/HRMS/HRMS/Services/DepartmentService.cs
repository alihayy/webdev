﻿using HRMS.Models;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Reflection;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace HRMS.Services
{
    public class DepartmentService
    {
        [Parameter]
        public string Id { get; set; }
        protected AppDbContext context;
        
        public DepartmentService(AppDbContext context)
        {
            this.context = context;
        }

        public async Task<List<SelectListItem>> GetAllCompaniesAsync()
        {
            
            return await context.companies.Select(x => new SelectListItem
            {
                Value = x.Id.ToString(),
                Text = x.CompanyName
            }).ToListAsync();
            
        }
        public async Task<List<Department>> GetAllDepartmentsAsync()
        {
            return await context.departments.Include(x => x.Company).ToListAsync();
        }
        
        public async Task<bool> AddDepartment(Department department)
        {
         
            bool isDepartmentDuplicate = await context.departments.AnyAsync(d => d.DepartmentName == department.DepartmentName && d.CompanyId == department.CompanyId);
            if (isDepartmentDuplicate)
            {
                throw new ArgumentException("Department name already exists for the company.");
            }
            bool isEmailDuplicate = await context.departments.AnyAsync(c => c.Email == department.Email);
            if (isEmailDuplicate)
            {
                throw new ArgumentException("Department email already exists.");
            }
            if (department.Id == 0)
            {
                await context.departments.AddAsync(department);
            
            }
            var editDepartment = context.departments.Where(x => x.Id == department.Id).FirstOrDefault();
            await context.SaveChangesAsync();
            return true;
        }
        public async Task<Department> GetDepartmentAsync(int Id)
        {
            Department department = await context.departments.FirstOrDefaultAsync(x => x.Id.Equals(Id));
            return department;
        }


        public async Task<Department> DeleteDepartment(Department department)
        {
            if (department.Id != 0)
            {
                var existingDepartment = await context.departments.FindAsync(department.Id);

                context.departments.Remove(existingDepartment);
                await context.SaveChangesAsync();
                return existingDepartment;
            }
            return null;
        }

    }
}