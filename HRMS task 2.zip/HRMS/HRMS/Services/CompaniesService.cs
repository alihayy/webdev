﻿using HRMS.Models;
using Microsoft.AspNetCore.Components;
using Microsoft.EntityFrameworkCore;

namespace HRMS.Services
{
    public class CompaniesService
    {
        [Parameter]
        public string Id { get; set; }
        protected AppDbContext context;
        public CompaniesService(AppDbContext context)
        {
            this.context = context;
        }
        public async Task<List<Company>> GetAllCompaniesAsync()
        {
            return await context.companies.ToListAsync();
        }

        public async Task<bool> AddCompany(Company companies)
        {
            bool isNameDuplicate = await context.companies.AnyAsync(c => c.CompanyName == companies.CompanyName);
            if (isNameDuplicate)
            {

                throw new ArgumentException("Company name already exists.");
            }
            bool isEmailDuplicate = await context.companies.AnyAsync(c => c.Email == companies.Email);
            if (isEmailDuplicate)
            {
                throw new ArgumentException("Company email already exists.");
            }
             if (companies.Id == 0 )
            {
                await context.companies.AddAsync(companies);
            }
            var editCompany = context.companies.Where(x => x.Id == companies.Id).FirstOrDefault();
            await context.SaveChangesAsync();
            return true;
        }
        public async Task<Company> GetCompanyById(int Id)
        {
            Company companies = await context.companies.FirstOrDefaultAsync(x => x.Id.Equals(Id));
            return companies;
        }


        public async Task<Company> DeleteCompany(Company companies)
        {
            if (companies.Id != 0)
            {
                var existingCompanies = await context.companies.FindAsync(companies.Id);

                context.companies.Remove(existingCompanies);
                await context.SaveChangesAsync();
                return existingCompanies;
            }
            return null;
        }

    }
}

