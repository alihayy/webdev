﻿using HRMS.Models;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace HRMS.Services
{
    public class EmployeeService
    {
        [Parameter]
        public string Id { get; set; }
        protected AppDbContext context;
        public EmployeeService(AppDbContext context)
        {
            this.context = context;
        }
        public async Task<List<SelectListItem>> GetAllCompaniesAsync()
        {
            return await context.companies.Select(x => new SelectListItem
            {
                Value = x.Id.ToString(),
                Text = x.CompanyName
            }).ToListAsync();
        }
        public async Task<List<SelectListItem>> GetAllRolesAsync()
        {
            return await context.roles.Select(x => new SelectListItem
            {
                Value = x.Id.ToString(),
                Text = x.Name
            }).ToListAsync();
        }
        public async Task<List<SelectListItem>> GetAllDepartmentsAsync()
        {
            //var result = await context.Employees.Include(x => x.DepartmentId==x.CompanyId).ToListAsync();
            return await context.departments.Select(x => new SelectListItem
            {
                Value = x.Id.ToString(),
                
                Text = x.DepartmentName

  
            }).ToListAsync();
        }
        public async Task<List<SelectListItem>> GetAllEmployeeAsync()
        {
            //var result = await context.Employees.Include(x => x.DepartmentId==x.CompanyId).ToListAsync();
            return await context.Employees.Select(x => new SelectListItem
            {
                Value = x.Id.ToString(),

                Text = x.EmployeeName


            }).ToListAsync();
        }
        public async Task<List<SelectListItem>> GetDepartmentbyid(int companyid)
        {
            return await context.departments.Where(x => x.CompanyId == companyid).Select(x => new SelectListItem()
            { Value = x.Id.ToString(), Text = x.DepartmentName }).ToListAsync();
        }
        public async Task<List<Employee>> GetAllEmployeesAsync()
        {
            try
            {
                var result = await context.Employees.Include(x => x.Department).Include(x => x.Department.Company).Include(x => x.Role).ToListAsync();
                return result;
            }
            catch (Exception ex)
            {

                throw;
            }

            //return await context.Employees
            //            .Include(x => x.Department)  // Include the Department information
            //            .ToListAsync();
        }
        public async Task<bool> IsRoleUniqueForCompanyAndDepartment(int companyId, int departmentId, int roleId)
        {
            var existingEmployee = await context.Employees
                .AnyAsync(e => e.CompanyId == companyId && e.DepartmentId == departmentId && e.RoleId == roleId);

            return !existingEmployee;
        }

        public async Task<bool> AddEmployee(Employee employee)
        {
            try
            {
                if (!await IsRoleUniqueForCompanyAndDepartment(employee.CompanyId, employee.DepartmentId, employee.RoleId))
                {
                    throw new InvalidOperationException("The role is not unique for the given company and department.");
                }

                if (employee.Id == 0)
                {
                    await context.Employees.AddAsync(employee);
                }
                var editEmployee = context.Employees.Where(x => x.Id == employee.Id).FirstOrDefault();
                await context.SaveChangesAsync();
                return true;
            }
            catch (Exception ex)
            {

                throw;
            }
            
        }
        public async Task<Employee> GetEmployeeById(int Id)
        {
           Employee employee = await context.Employees.FirstOrDefaultAsync(x => x.Id.Equals(Id));
            return employee;
        }

      
        public async Task<Employee> DeleteEmployee(Employee employee)
        {
            if (employee.Id != 0)
            {
                var existingEmployee = await context.Employees.FindAsync(employee.Id);
                
                    context.Employees.Remove(existingEmployee);
                    await context.SaveChangesAsync();
                    return existingEmployee;
                            }
            return null; 
        }

    }
}
